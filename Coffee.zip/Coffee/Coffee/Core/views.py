from django.core.paginator import Paginator
from django.shortcuts import render
from .models import Foro

# Create your views here.

def index (request):

    return render(request,'Core/index.html')

def products (request):

    return render(request,'Core/products.html')

def store (request):

    return render(request,'Core/store.html')

def about (request):

    return render(request,'Core/about.html')

def Foro(request):
    foro=Foro.objects.all()
    paginator = Paginator(foro, 3) 
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request, "foro/foro.html", {"page_obj": page_obj})
