from django.contrib import admin

from .models import Foro
admin.site.register(Foro)

# Register your models here.
